# Pirna Jetzt

Angebote, Saisonkarten, Abverkäufe und Events in Pirna – gebündelt, mit Tipps für Gäste und Einwohner.

- `index.html` – die App (Angebote, Events, Tipps). Echte Daten im Block `DATA` pflegen.
- `atlas.html` – Kartenansicht mit OpenStreetMap-Daten und Lückenanalyse.

## Auf GitHub Pages veröffentlichen
1. Neues Repo erstellen und alle Dateien hochladen
2. Settings → Pages → Branch `main`, Ordner `/ (root)` → Save
3. Nach 1–2 Minuten live unter `https://DEINNAME.github.io/REPONAME/`

Hinweis: Die Einträge in `index.html` sind Beispieldaten.
